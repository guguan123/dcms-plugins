
	# auhor Drk in

	恭喜你买了！！如果你有任何问题，请写
	
	#1. 将 photo_tender 文件夹放入网站的根。
	#2. 加汽缸
	#3. 如果你通过 admin 添加链接，则计数器： /photo_tender/count.php
	#4. 把...写在档案里  sys/inc/fnc.php 最后
	# - 摄影比赛
	include_once H.'photo_tender/class/end.php';
	#5. 就这样！

	
	
	