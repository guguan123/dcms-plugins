﻿Скрипт: "Подарки для DCMS Social 1.9.9"
Версия: 1.0

Автор: Ricky Guide
Связь:
- ICQ: 
684234712
- Vk: http://vk.cc/5dVVZA
- Spaces: http://vk.cc/59f2Hj
- Email: Ricky55Guide@mail.ru
- Сайты:
http://LoveTap.Ru

Описание:
- Отличная Сборка Подарков для DCMS social 1.9.9 
- 212 Различных Подарков для вашего сайта 

Установка:
- Распаковать архив в корневую папку;
- Залить таблы из файла ricky_guide.sql ;

• Все!!!
• Ждите следующую версию!!!
• Ricky Guide 