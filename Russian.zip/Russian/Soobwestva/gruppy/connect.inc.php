<?php
include_once '../sys/inc/start.php';
  include_once '../sys/inc/compress.php';
 include_once '../sys/inc/sess.php';
 include_once '../sys/inc/home.php';
 include_once '../sys/inc/settings.php';
 include_once '../sys/inc/db_connect.php';
?>